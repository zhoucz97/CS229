import numpy as np
from unittest import TestCase
from gradescope_utils.autograder_utils.decorators import weight, visibility

import p1_nn
import p4_ica

from solution import p4_sol
from solution import p1_sol

class TestPS4(TestCase):

    def helper_q4c_update_W(self, sanity):
        np.random.seed(342341)
        n = 10

        x = np.random.normal(size=(n,))
        W = np.random.normal(size=(n, n))

        expected = p4_sol.update_W(W, x, 0.2)

        actual = p4_ica.update_W(W, x, 0.2)

        if sanity:
            np.testing.assert_array_equal(actual.shape, expected.shape, err_msg='Assert shape equality')
        else:
            np.testing.assert_almost_equal(actual, expected, decimal=4, err_msg='Assert same values')


    @weight(3)
    @visibility("after_published")
    def test_q4c_update_W(self):
        self.helper_q4c_update_W(sanity=False)

    @weight(0)
    @visibility("visible")
    def test_q4c_update_W_sanity(self):
        self.helper_q4c_update_W(sanity=True)

    def helper_q4c_unmix(self, sanity):
        np.random.seed(342341)
        m = 20
        n = 10

        X = np.random.normal(size=(m, n,))
        W = np.random.normal(size=(n, n))

        expected = p4_sol.unmix(X, W)

        actual = p4_ica.unmix(X, W)

        if sanity:
            np.testing.assert_array_equal(actual.shape, expected.shape, err_msg='Assert shape equality')
        else:
            np.testing.assert_almost_equal(actual, expected, decimal=4, err_msg='Assert same values')

    @weight(2)
    @visibility("after_published")
    def test_q4c_unmix(self):
        self.helper_q4c_unmix(sanity=False)

    @weight(0)
    @visibility("visible")
    def test_q4c_unmix_sanity(self):
        self.helper_q4c_unmix(sanity=True)

    def helper_q1a_softmax(self, sanity):
        np.random.seed(342341)
        n = 10

        x = np.random.normal(size=(n,))
        grad_outputs = np.random.normal(size=(n, ))

        expected = p1_sol.backward_softmax(x, grad_outputs)

        actual = p1_nn.backward_softmax(x, grad_outputs)

        if sanity:
            np.testing.assert_array_equal(actual.shape, expected.shape, err_msg='Assert shape equality')
        else:
            np.testing.assert_almost_equal(actual, expected, decimal=4, err_msg='Assert same values')

    @weight(2)
    @visibility("after_published")
    def test_q1a_softmax(self):
        self.helper_q1a_softmax(sanity=False)

    @weight(0)
    @visibility("visible")
    def test_q1a_softmax_sanity(self):
        self.helper_q1a_softmax(sanity=True)

    def helper_q1a_relu(self, sanity):
        np.random.seed(342341)
        n = 10

        x = np.random.normal(size=(n,))
        grad_outputs = np.random.normal(size=(n, ))

        expected = p1_sol.backward_relu(x, grad_outputs)

        actual = p1_nn.backward_relu(x, grad_outputs)

        if sanity:
            np.testing.assert_array_equal(actual.shape, expected.shape, err_msg='Assert shape equality')
        else:
            np.testing.assert_almost_equal(actual, expected, decimal=4, err_msg='Assert same values')

    @weight(2)
    @visibility("after_published")
    def test_q1a_relu(self):
        self.helper_q1a_relu(sanity=False)

    @weight(0)
    @visibility("visible")
    def test_q1a_relu_sanity(self):
        self.helper_q1a_relu(sanity=True)

    def helper_q1a_convolution(self, sanity, variable_to_test):
        np.random.seed(342341)
        in_channels = 3
        out_channels = 4
        in_width = 10
        in_height = 12
        conv_width = 4
        conv_height = 5

        out_shape = (out_channels, in_width - conv_width + 1, in_height - conv_height + 1)

        x = np.random.normal(size=(in_channels, in_width, in_height))
        conv_W = np.random.normal(size=(out_channels, in_channels, conv_width, conv_height))
        conv_b = np.random.normal(size=(out_channels,))

        grad_outputs = np.random.normal(size=out_shape)

        expected = p1_sol.backward_convolution(conv_W, conv_b, x, grad_outputs)[variable_to_test]

        actual = p1_nn.backward_convolution(conv_W, conv_b, x, grad_outputs)[variable_to_test]

        if sanity:
            np.testing.assert_array_equal(actual.shape, expected.shape, err_msg='Assert shape equality')
        else:
            np.testing.assert_almost_equal(actual, expected, decimal=4, err_msg='Assert same values')

    @weight(2)
    @visibility("after_published")
    def test_q1a_convolution_W(self):
        self.helper_q1a_convolution(sanity=False, variable_to_test=0)

    @weight(0)
    @visibility("visible")
    def test_q1a_convolution_W_sanity(self):
        self.helper_q1a_convolution(sanity=True, variable_to_test=0)

    @weight(2)
    @visibility("after_published")
    def test_q1a_convolution_b(self):
        self.helper_q1a_convolution(sanity=False, variable_to_test=1)

    @weight(0)
    @visibility("visible")
    def test_q1a_convolution_b_sanity(self):
        self.helper_q1a_convolution(sanity=True, variable_to_test=1)

    @weight(2)
    @visibility("after_published")
    def test_q1a_convolution_data(self):
        self.helper_q1a_convolution(sanity=False, variable_to_test=2)

    @weight(0)
    @visibility("visible")
    def test_q1a_convolution_data_sanity(self):
        self.helper_q1a_convolution(sanity=True, variable_to_test=2)

    def helper_q1a_max_pool(self, sanity):
        np.random.seed(342341)
        in_channels = 3
        in_width = 10
        in_height = 12
        pool_width = 5
        pool_height = 4

        out_shape = (in_channels, in_width // pool_width, in_height // pool_height)

        x = np.random.normal(size=(in_channels, in_width, in_height))

        grad_outputs = np.random.normal(size=out_shape)

        expected = p1_sol.backward_max_pool(x, pool_width, pool_height, grad_outputs)

        actual = p1_nn.backward_max_pool(x, pool_width, pool_height, grad_outputs)

        if sanity:
            np.testing.assert_array_equal(actual.shape, expected.shape, err_msg='Assert shape equality')
        else:
            np.testing.assert_almost_equal(actual, expected, decimal=4, err_msg='Assert same values')

    @weight(2)
    @visibility("after_published")
    def test_q1a_max_pool(self):
        self.helper_q1a_max_pool(sanity=False)

    @weight(0)
    @visibility("visible")
    def test_q1a_max_pool_sanity(self):
        self.helper_q1a_max_pool(sanity=True)

    def helper_q1a_cross_entropy(self, sanity):
        np.random.seed(342341)
        n = 12

        probabilities = np.random.uniform(size=(n,))
        labels = np.array([i == 3 for i in range(n)], dtype=float)

        expected = p1_sol.backward_cross_entropy_loss(probabilities, labels)

        actual = p1_nn.backward_cross_entropy_loss(probabilities, labels)

        if sanity:
            np.testing.assert_array_equal(actual.shape, expected.shape, err_msg='Assert shape equality')
        else:
            np.testing.assert_almost_equal(actual, expected, decimal=4, err_msg='Assert same values')

    @weight(2)
    @visibility("after_published")
    def test_q1a_cross_entropy(self):
        self.helper_q1a_cross_entropy(sanity=False)

    @weight(0)
    @visibility("visible")
    def test_q1a_cross_entropy_sanity(self):
        self.helper_q1a_cross_entropy(sanity=True)

    def helper_q1a_linear(self, sanity, variable_to_test):
        np.random.seed(342341)
        n = 12
        output_n = 34

        x = np.random.normal(size=(n,))
        weights = np.random.normal(size=(n, output_n))
        bias = np.random.normal(size=(output_n,))

        grad_outputs = np.random.normal(size=(output_n,))

        expected = p1_sol.backward_linear(weights, bias, x, grad_outputs)[variable_to_test]

        actual = p1_nn.backward_linear(weights, bias, x, grad_outputs)[variable_to_test]

        if sanity:
            np.testing.assert_array_equal(actual.shape, expected.shape, err_msg='Assert shape equality')
        else:
            np.testing.assert_almost_equal(actual, expected, decimal=4, err_msg='Assert same values')

    @weight(2)
    @visibility("after_published")
    def test_q1a_linear_weights(self):
        self.helper_q1a_linear(sanity=False, variable_to_test=0)

    @weight(0)
    @visibility("visible")
    def test_q1a_linear_weights_sanity(self):
        self.helper_q1a_linear(sanity=True, variable_to_test=0)

    @weight(2)
    @visibility("after_published")
    def test_q1a_linear_bias(self):
        self.helper_q1a_linear(sanity=False, variable_to_test=1)

    @weight(0)
    @visibility("visible")
    def test_q1a_linear_bias_sanity(self):
        self.helper_q1a_linear(sanity=True, variable_to_test=1)

    @weight(2)
    @visibility("after_published")
    def test_q1a_linear_data(self):
        self.helper_q1a_linear(sanity=False, variable_to_test=2)

    @weight(0)
    @visibility("visible")
    def test_q1a_linear_data_sanity(self):
        self.helper_q1a_linear(sanity=True, variable_to_test=2)


    def helper_q1b_backward_prop(self, sanity, variable_to_test):
        np.random.seed(342341)

        x = np.random.normal(size=(1, 28, 28))
        labels = np.array([i == 3 for i in range(10)], dtype=float)

        params = p1_sol.get_initial_params()

        all_expected = p1_sol.backward_prop(x, labels, params, p1_nn)

        expected = all_expected[variable_to_test]

        actual = p1_nn.backward_prop(x, labels, params)[variable_to_test]

        if sanity:
            np.testing.assert_array_equal(actual.shape, expected.shape, err_msg='Assert shape equality')
        else:
            self.assertGreater(np.linalg.norm(all_expected['y_grad']), 0, msg='Need a non-trivial gradient')
            self.assertGreater(np.linalg.norm(expected), 0, msg='Need a non-trivial gradient')
            np.testing.assert_almost_equal(actual, expected, decimal=4, err_msg='Assert same values')

    @weight(3)
    @visibility("after_published")
    def test_q1b_W1(self):
        self.helper_q1b_backward_prop(sanity=False, variable_to_test='W1')

    @weight(0)
    @visibility("visible")
    def test_q1b_W1_sanity(self):
        self.helper_q1b_backward_prop(sanity=True, variable_to_test='W1')

    @weight(2)
    @visibility("after_published")
    def test_q1b_W2(self):
        self.helper_q1b_backward_prop(sanity=False, variable_to_test='W2')

    @weight(0)
    @visibility("visible")
    def test_q1b_W2_sanity(self):
        self.helper_q1b_backward_prop(sanity=True, variable_to_test='W2')

    @weight(3)
    @visibility("after_published")
    def test_q1b_b1(self):
        self.helper_q1b_backward_prop(sanity=False, variable_to_test='b1')

    @weight(0)
    @visibility("visible")
    def test_q1b_b1_sanity(self):
        self.helper_q1b_backward_prop(sanity=True, variable_to_test='b1')

    @weight(2)
    @visibility("after_published")
    def test_q1b_b2(self):
        self.helper_q1b_backward_prop(sanity=False, variable_to_test='b2')

    @weight(0)
    @visibility("visible")
    def test_q1b_b2_sanity(self):
        self.helper_q1b_backward_prop(sanity=True, variable_to_test='b2')
