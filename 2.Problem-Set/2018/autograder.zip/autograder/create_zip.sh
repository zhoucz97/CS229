rm autograder.zip
zip -r autograder.zip \
setup.sh run_autograder requirements.txt main.py tests/*.py solution/*.py
