#!/usr/bin/env bash

# get ubuntu packages
yes | apt-get install qtcreator python3 python3-pip

# get python stuff
pip3 install gradescope-utils
pip3 install -r /autograder/source/requirements.txt
